MBC Store — The Markk Brandon Collective App Store

Install steps (Android):
1. Unzip this folder on your phone (Files app → tap the zip → Extract).
2. Open MBC-Store-v1.0.0.apk from the extracted folder.
3. Tap Install when Android asks. Allow installs from your file app if prompted.
4. Open MBC Store and install or update any Collective app from the catalog.

Online catalog: https://themarkkbradoncollective.github.io/main/download/

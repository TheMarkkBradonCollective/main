The Verse — StrainVerse · SpiritsVerse · Cookverse

Install steps (Android):
1. Unzip this folder on your phone.
2. Tap each APK you want and confirm Install.
3. Or install all three — they are separate apps in the Verse family.

- StrainVerse v1.2.0 → strainverse-v1.2.0.apk
- SpiritsVerse v1.5.4 → spiritsverse-v1.5.4.apk
- Cookverse v1.0.13 → cookverse-v1.0.13.apk

MBC App Store: https://themarkkbradoncollective.github.io/main/download/
